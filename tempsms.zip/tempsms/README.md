**Tempsms**

## Running with Docker

This project includes a multi-stage Docker setup using Eclipse Temurin JDK 17 for building and running the Java Spring Boot application. The default exposed port is **8080**.

### Requirements
- Docker and Docker Compose installed
- No external services (databases, caches) are required by default
- No required environment variables are specified by default, but you may uncomment and use an `.env` file if needed

### Build and Run

To build and start the application:

```sh
docker compose up --build
```

This will build the application using Maven (with dependencies cached for faster builds) and run it in a container as a non-root user. The application will be available at [http://localhost:8080](http://localhost:8080).

### Configuration
- The application runs with JVM options optimized for containers (`JAVA_OPTS` is set in the Dockerfile)
- If you need to provide environment variables, create a `.env` file in the project root and uncomment the `env_file` line in `docker-compose.yml`
- No persistent volumes or additional services are configured by default

### Ports
- **8080**: Exposed by the container and mapped to the host (Spring Boot default)

If you need to add databases or other services, update the `docker-compose.yml` accordingly.
